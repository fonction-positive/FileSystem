#include "filesystem.h"
#include <stdio.h>
#include <string.h>

int main() {
    char command[256];
    char arg1[256], arg2[256];

    printf("Welcome to the Virtual File System.\n");
    printf("Type 'exit' to quit. Type 'help' for a list of commands.\n");
    printf("if you are first time using the system, please type 'mkfs' to format the partition.\n");

    while (1) {
        printf("%s> ", current_path);
        fgets(command, sizeof(command), stdin);
        command[strcspn(command, "\n")] = 0;

        if (strcmp(command, "exit") == 0) {
            break;
        } else if (strcmp(command, "mkfs") == 0) {
            format_partition();
        } else if (strcmp(command, "ls") == 0) {
            list_directory();
        } else if (strcmp(command, "pwd") == 0) {
            print_working_directory();
        } else if (sscanf(command, "cd %s", arg1) == 1) {
            change_directory(arg1);
        } else if (sscanf(command, "mkdir %s", arg1) == 1) {
            create_directory(arg1);
        } else if (sscanf(command, "rmdir %s", arg1) == 1) {
            delete_directory(arg1);
        } else if (sscanf(command, "mvdir %s %s", arg1, arg2) == 2) {
            move_directory(arg1, arg2);
        } else if (sscanf(command, "touch %s", arg1) == 1) {
            create_file(arg1);
        } else if (sscanf(command, "rm %s", arg1) == 1) {
            delete_file(arg1);
        } else if (sscanf(command, "cat %s", arg1) == 1) {
            open_file(arg1);
        } else if (sscanf(command, "echo %s > %s", arg1, arg2) == 2) {
            write_file(arg2, arg1);
        } else if (sscanf(command, "mv %s %s", arg1, arg2) == 2) {
            move_file(arg1, arg2);
        } else if (sscanf(command, "cp %s %s", arg1, arg2) == 2) {
            copy_file(arg1, arg2);
        } else if (sscanf(command, "perm %s", arg1) == 1) {
            show_permissions(arg1);
        } else if (sscanf(command, "chmod %s %s", arg1, arg2) == 2) {
            change_permissions(arg1, arg2);
        } else if (sscanf(command, "ln %s %s", arg1, arg2) == 2) {
            link_file(arg1, arg2);
        } else if (strcmp(command, "help") == 0) {
            show_help();
        } else {
            printf("Invalid command.\n");
        }
    }

    printf("Exiting Virtual File System.\n");
    return 0;
}