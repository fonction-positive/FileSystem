#ifndef FILESYSTEM_H
#define FILESYSTEM_H

#include <stddef.h>  // 添加这行来支持 size_t 类型 // Ajoutez cette ligne pour prendre en charge le type size_t

#define BLOCK_SIZE 4096
#define MAX_FILES 1024
#define MAX_FILENAME_LENGTH 256
#define MAX_PATH_LENGTH 1024

// 添加分页相关的结构 // Ajouter la structure liée à la pagination
#define PAGE_SIZE 4096
#define MAX_FILE_PAGES 256  // 每个文件最多可以使用的页数 // Nombre maximal de pages utilisables par fichier

typedef struct {
    int page_index;     // 页面索引 // Index de la page
    int is_used;        // 是否被使用 // Indique si elle est utilisée
    int next_page;      // 链接到下一个页面，-1表示结束 // Lien vers la page suivante, -1 signifie la fin
} PageTableEntry;

// 添加权限定义 // Définition des permissions
#define PERM_READ    4
#define PERM_WRITE   2
#define PERM_EXECUTE 1

// 在 FileEntry 结构体中添加权限字段 // Ajouter un champ de permissions dans la structure FileEntry
typedef struct {
    char name[MAX_FILENAME_LENGTH];
    int is_directory;   // 是否为目录 // Indique si c'est un répertoire
    size_t size;        // 文件大小 // Taille du fichier
    int first_page;     // 第一个页面索引 // Index de la première page
    int page_count;     // 文件占用的页面数量 // Nombre de pages occupées par le fichier
    unsigned char permissions;  // 权限 // Permissions
    int link_count;    // 硬链接计数 // Nombre de liens physiques
} FileEntry;

typedef struct {
    FileEntry files[MAX_FILES];  // 文件条目数组 // Tableau des entrées de fichiers
    PageTableEntry page_table[MAX_FILES * MAX_FILE_PAGES];  // 页面表 // Table des pages
    int free_page_head;  // 空闲页面链表的头部 // Tête de la liste des pages libres
} SuperBlock;

void format_partition(); // 格式化分区 // Formater la partition
void create_file(const char *filename); // 创建文件 // Créer un fichier
void delete_file(const char *filename); // 删除文件 // Supprimer un fichier
void move_file(const char *source, const char *destination); // 移动文件 // Déplacer un fichier
void copy_file(const char *source, const char *destination); // 复制文件 // Copier un fichier
void create_directory(const char *dirname); // 创建目录 // Créer un répertoire
void delete_directory(const char *dirname); // 删除目录 // Supprimer un répertoire
void list_directory(); // 列出当前目录内容 // Lister le contenu du répertoire actuel
void change_directory(const char *dirname); // 切换当前目录 // Changer de répertoire
void print_working_directory(); // 显示当前路径 // Afficher le chemin actuel
void open_file(const char *filename); // 打开文件 // Ouvrir un fichier
void write_file(const char *filename, const char *content); // 写入文件 // Écrire dans un fichier
void move_directory(const char *source, const char *destination); // 移动目录 // Déplacer un répertoire
void show_permissions(const char *path); // 显示权限 // Afficher les permissions
void change_permissions(const char *path, const char *perm_str); // 修改权限 // Modifier les permissions
void link_file(const char *source, const char *link_name); // 创建硬链接 // Créer un lien physique
void show_help(); // 显示帮助信息 // Afficher l'aide

extern char current_path[MAX_PATH_LENGTH];  // 添加当前路径的全局变量 // Ajouter une variable globale pour le chemin actuel

#endif // FILESYSTEM_H