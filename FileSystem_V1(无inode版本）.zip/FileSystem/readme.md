Exécutez la commande make pour générer le fichier exécutable FileSystem.
Exécutez ./FileSystem pour l’exécuter.

执行 make 命令会生成可执行文件 FileSystem
执行 ./FileSystem 即可运行
