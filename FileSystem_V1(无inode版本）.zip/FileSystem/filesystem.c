#include "filesystem.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>

void show_help() {
    printf("Available commands:\n");
    printf("  mkfs                  - Format the virtual disk\n");
    printf("  ls                    - List directory contents\n");
    printf("  cd <dir>              - Change directory\n");
    printf("  mkdir <dir>           - Create a directory\n");
    printf("  rmdir <dir>           - Delete a directory\n");
    printf("  pwd                   - Print current working directory\n");
    printf("  mvdir <dir1> <dir2>   - Move or rename a directory\n");
    printf("  touch <file>          - Create a new empty file\n");
    printf("  rm <file>             - Delete a file\n");
    printf("  cat <file>            - Open and display the contents of a file\n");
    printf("  echo <text> > <file>  - Write text to a file\n");
    printf("  mv <file1> <file2>    - Move or rename a file\n");
    printf("  cp <file1> <file2>    - Copy a file\n");
    printf("  perm <file>           - Show file permissions\n");
    printf("  chmod <path> <perm>   - Change file/directory permissions (e.g., rw-, r-x)\n");
    printf("  ln <source> <link>    - Create a hard link to a file\n");
    printf("  help                  - Show this help message\n");
    printf("  exit                  - Exit the virtual file system\n");
}

void create_file(const char *filename) {
    // 检查虚拟磁盘是否存在 / Vérifier si le disque virtuel existe
    if (access("virtual_disk.dat", F_OK) == -1) {
        printf("Error: Disk partition not created.\n");
        return;
    }

    // 打开虚拟磁盘 / Ouvrir le disque virtuel
    FILE *vfs = fopen("virtual_disk.dat", "rb+");
    if (!vfs) {
        perror("Error opening virtual disk");
        return;
    }

    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    // 构建完整路径 / Construire le chemin complet
    char full_path[MAX_PATH_LENGTH];
    if (filename[0] == '/') {
        strncpy(full_path, filename, MAX_PATH_LENGTH - 1);
    } else {
        if (strcmp(current_path, "/") == 0) {
            snprintf(full_path, MAX_PATH_LENGTH, "/%s", filename);
        } else {
            snprintf(full_path, MAX_PATH_LENGTH, "%s/%s", current_path, filename);
        }
    }

    // 检查文件是否已存在 / Vérifier si le fichier existe déjà
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, full_path) == 0) {
            printf("Error: File already exists.\n");
            fclose(vfs);
            return;
        }
    }

    // 查找空闲文件条目 / Trouver une entrée de fichier libre
    int file_index = -1;
    for (int i = 0; i < MAX_FILES; i++) {
        if (superblock.files[i].name[0] == '\0') {
            file_index = i;
            break;
        }
    }

    if (file_index == -1) {
        printf("Error: Maximum number of files reached.\n");
        fclose(vfs);
        return;
    }

    // 分配初始页面 / Allouer une page initiale
    int first_page = -1;
    for (int i = 0; i < MAX_FILES * MAX_FILE_PAGES; i++) {
        if (!superblock.page_table[i].is_used) {
            first_page = i;
            superblock.page_table[i].is_used = 1;
            superblock.page_table[i].next_page = -1;
            break;
        }
    }

    if (first_page == -1) {
        printf("Error: No free pages available.\n");
        fclose(vfs);
        return;
    }

    // 初始化文件条目 / Initialiser l'entrée du fichier
    strncpy(superblock.files[file_index].name, full_path, MAX_FILENAME_LENGTH);
    superblock.files[file_index].is_directory = 0;
    superblock.files[file_index].size = 0;
    superblock.files[file_index].first_page = first_page;
    superblock.files[file_index].page_count = 1;
    superblock.files[file_index].permissions = PERM_READ | PERM_WRITE;  // 默认读写权限 / Permissions par défaut : lecture et écriture
    superblock.files[file_index].link_count = 1;  // 初始化链接计数为1 / Initialiser le nombre de liens à 1

    // 更新超级块 / Mettre à jour le superbloc
    fseek(vfs, 0, SEEK_SET);
    fwrite(&superblock, sizeof(SuperBlock), 1, vfs);
    printf("File created: %s\n", full_path);

    fclose(vfs);
}

void delete_file(const char *filename) {
    // 检查虚拟磁盘是否存在 // Vérifier si le disque virtuel existe
    if (access("virtual_disk.dat", F_OK) == -1) {
        printf("Error: Disk partition not created.\n");
        return;
    }

    // 打开虚拟磁盘文件 // Ouvrir le fichier du disque virtuel
    FILE *vfs = fopen("virtual_disk.dat", "rb+");
    if (!vfs) {
        perror("Error opening virtual disk");
        return;
    }

    // 读取超级块信息 // Lire les informations du superbloc
    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    // 构建完整路径 // Construire le chemin complet
    char full_path[MAX_PATH_LENGTH];
    if (filename[0] == '/') {
        strncpy(full_path, filename, MAX_PATH_LENGTH - 1);
    } else {
        if (strcmp(current_path, "/") == 0) {
            snprintf(full_path, MAX_PATH_LENGTH, "/%s", filename);
        } else {
            snprintf(full_path, MAX_PATH_LENGTH, "%s/%s", current_path, filename);
        }
    }

    // 查找并删除文件 // Rechercher et supprimer le fichier
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, full_path) == 0 && !superblock.files[i].is_directory) {
            int first_page = superblock.files[i].first_page;
            int link_count = 0;

            // 计算实际的硬链接数量 // Calculer le nombre réel de liens matériels
            for (int j = 0; j < MAX_FILES; j++) {
                if (superblock.files[j].name[0] != '\0' && 
                    !superblock.files[j].is_directory &&
                    superblock.files[j].first_page == first_page) {
                    link_count++;
                }
            }

            if (link_count <= 1) {
                // 只有一个链接，释放所有页面 // Dernier lien, libérer toutes les pages
                int current_page = first_page;
                while (current_page != -1) {
                    int next_page = superblock.page_table[current_page].next_page;
                    superblock.page_table[current_page].is_used = 0;
                    superblock.page_table[current_page].next_page = superblock.free_page_head;
                    superblock.free_page_head = current_page;
                    current_page = next_page;
                }
                memset(&superblock.files[i], 0, sizeof(FileEntry));
                printf("File deleted: %s\n", full_path);
            } else {
                // 仍有其他链接，更新链接计数 // Mettre à jour le nombre de liens restants
                for (int j = 0; j < MAX_FILES; j++) {
                    if (superblock.files[j].name[0] != '\0' && 
                        !superblock.files[j].is_directory &&
                        superblock.files[j].first_page == first_page) {
                        superblock.files[j].link_count = link_count - 1;
                    }
                }
                // 清除当前文件条目 // Effacer l'entrée du fichier actuel
                memset(&superblock.files[i], 0, sizeof(FileEntry));
                printf("File unlinked: %s (remaining links: %d)\n", 
                       full_path, link_count - 1);
            }

            // 更新超级块 // Mettre à jour le superbloc
            fseek(vfs, 0, SEEK_SET);
            fwrite(&superblock, sizeof(SuperBlock), 1, vfs);
            fclose(vfs);
            return;
        }
    }

    // 文件未找到 // Fichier non trouvé
    printf("Error: File not found.\n");
    fclose(vfs);
}

void move_file(const char *source, const char *destination) {
    // 检查虚拟磁盘文件是否存在  
    // Vérifier si la partition du disque virtuel existe  
    if (access("virtual_disk.dat", F_OK) == -1) {
        printf("Error: Disk partition not created.\n");  // 错误：磁盘分区未创建  
        return;
    }

    // 以读写模式打开虚拟磁盘  
    // Ouvrir le disque virtuel en mode lecture et écriture  
    FILE *vfs = fopen("virtual_disk.dat", "rb+");
    if (!vfs) {
        perror("Error opening virtual disk");  // 打开虚拟磁盘错误  
        return;
    }

    // 读取超级块  
    // Lire le superbloc  
    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    // 构建源文件完整路径  
    // Construire le chemin complet du fichier source  
    char src_path[MAX_PATH_LENGTH];
    if (source[0] == '/') {  // 绝对路径 | Chemin absolu  
        strncpy(src_path, source, MAX_PATH_LENGTH - 1);
    } else {  // 相对路径 | Chemin relatif  
        if (strcmp(current_path, "/") == 0) {
            snprintf(src_path, MAX_PATH_LENGTH, "/%s", source);
        } else {
            snprintf(src_path, MAX_PATH_LENGTH, "%s/%s", current_path, source);
        }
    }

    // 构建目标文件完整路径  
    // Construire le chemin complet du fichier de destination  
    char dest_path[MAX_PATH_LENGTH];
    if (destination[0] == '/') {  // 绝对路径 | Chemin absolu  
        strncpy(dest_path, destination, MAX_PATH_LENGTH - 1);
    } else {  // 相对路径 | Chemin relatif  
        if (strcmp(current_path, "/") == 0) {
            snprintf(dest_path, MAX_PATH_LENGTH, "/%s", destination);
        } else {
            snprintf(dest_path, MAX_PATH_LENGTH, "%s/%s", current_path, destination);
        }
    }

    // 在超级块中查找源文件  
    // Rechercher le fichier source dans le superbloc  
    int src_index = -1;
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, src_path) == 0 && !superblock.files[i].is_directory) {
            src_index = i;
            break;
        }
    }

    // 如果源文件不存在，则报错  
    // Si le fichier source n'existe pas, afficher une erreur  
    if (src_index == -1) {
        printf("Error: Source file not found.\n");  // 错误：源文件未找到  
        fclose(vfs);
        return;
    }

    // 检查目标路径是否已有文件  
    // Vérifier si un fichier existe déjà au chemin de destination  
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, dest_path) == 0) {
            printf("Error: Destination file already exists.\n");  // 错误：目标文件已存在  
            fclose(vfs);
            return;
        }
    }

    // 更新文件路径，即移动文件  
    // Mettre à jour le chemin du fichier, c'est-à-dire déplacer le fichier  
    strncpy(superblock.files[src_index].name, dest_path, MAX_FILENAME_LENGTH);

    // 保存超级块的更改  
    // Sauvegarder les modifications du superbloc  
    fseek(vfs, 0, SEEK_SET);
    fwrite(&superblock, sizeof(SuperBlock), 1, vfs);
    
    printf("File moved from %s to %s\n", src_path, dest_path);  // 文件已移动 | Fichier déplacé  

    fclose(vfs);  // 关闭虚拟磁盘 | Fermer le disque virtuel  
}

void copy_file(const char *source, const char *destination) {
    if (access("virtual_disk.dat", F_OK) == -1) {
        printf("Error: Disk partition not created.\n");
        return;
    }

    FILE *vfs = fopen("virtual_disk.dat", "rb+");
    if (!vfs) {
        perror("Error opening virtual disk");
        return;
    }

    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    // 构建源文件完整路径
    char src_path[MAX_PATH_LENGTH];
    if (source[0] == '/') {  // 绝对路径
        strncpy(src_path, source, MAX_PATH_LENGTH - 1);
    } else {  // 相对路径
        if (strcmp(current_path, "/") == 0) {
            snprintf(src_path, MAX_PATH_LENGTH, "/%s", source);
        } else {
            snprintf(src_path, MAX_PATH_LENGTH, "%s/%s", current_path, source);
        }
    }

    // 构建目标文件完整路径
    char dest_path[MAX_PATH_LENGTH];
    if (destination[0] == '/') {  // 绝对路径
        strncpy(dest_path, destination, MAX_PATH_LENGTH - 1);
    } else {  // 相对路径
        if (strcmp(current_path, "/") == 0) {
            snprintf(dest_path, MAX_PATH_LENGTH, "/%s", destination);
        } else {
            snprintf(dest_path, MAX_PATH_LENGTH, "%s/%s", current_path, destination);
        }
    }

    // 查找源文件
    int src_index = -1;
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, src_path) == 0 && !superblock.files[i].is_directory) {
            src_index = i;
            break;
        }
    }

    if (src_index == -1) {
        printf("Error: Source file not found.\n");
        fclose(vfs);
        return;
    }

    // 查找空闲文件条目
    int dest_index = -1;
    for (int i = 0; i < MAX_FILES; i++) {
        if (superblock.files[i].name[0] == '\0') {
            dest_index = i;
            break;
        }
    }

    if (dest_index == -1) {
        printf("Error: No free file entries available.\n");
        fclose(vfs);
        return;
    }

    // 为目标文件分配页面
    int first_dest_page = -1;
    int current_dest_page = -1;
    int current_src_page = superblock.files[src_index].first_page;
    
    // 复制所有页面
    while (current_src_page != -1) {
        // 分配新页面
        int new_page = -1;
        for (int i = 0; i < MAX_FILES * MAX_FILE_PAGES; i++) {
            if (!superblock.page_table[i].is_used) {
                new_page = i;
                superblock.page_table[i].is_used = 1;
                superblock.page_table[i].next_page = -1;
                break;
            }
        }

        if (new_page == -1) {
            printf("Error: No free pages available.\n");
            // 清理已分配的页面
            if (first_dest_page != -1) {
                int page = first_dest_page;
                while (page != -1) {
                    int next = superblock.page_table[page].next_page;
                    superblock.page_table[page].is_used = 0;
                    page = next;
                }
            }
            fclose(vfs);
            return;
        }

        // 复制页面内容
        char buffer[PAGE_SIZE];
        fseek(vfs, sizeof(SuperBlock) + current_src_page * PAGE_SIZE, SEEK_SET);
        fread(buffer, 1, PAGE_SIZE, vfs);
        fseek(vfs, sizeof(SuperBlock) + new_page * PAGE_SIZE, SEEK_SET);
        fwrite(buffer, 1, PAGE_SIZE, vfs);

        // 链接页面
        if (first_dest_page == -1) {
            first_dest_page = new_page;
        } else {
            superblock.page_table[current_dest_page].next_page = new_page;
        }
        current_dest_page = new_page;

        // 移动到下一个源页面
        current_src_page = superblock.page_table[current_src_page].next_page;
    }

    // 创建新文件条目
    strncpy(superblock.files[dest_index].name, dest_path, MAX_FILENAME_LENGTH);
    superblock.files[dest_index].is_directory = 0;
    superblock.files[dest_index].size = superblock.files[src_index].size;
    superblock.files[dest_index].first_page = first_dest_page;
    superblock.files[dest_index].page_count = superblock.files[src_index].page_count;

    // 更新超级块
    fseek(vfs, 0, SEEK_SET);
    fwrite(&superblock, sizeof(SuperBlock), 1, vfs);
    printf("File copied from %s to %s\n", src_path, dest_path);

    fclose(vfs);
}

void create_directory(const char *dirname) {
    FILE *vfs = fopen("virtual_disk.dat", "rb+");
    if (!vfs) {
        perror("Error opening virtual disk");
        return;
    }

    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    // 构建完整路径
    char full_path[MAX_PATH_LENGTH];
    if (dirname[0] == '/') {  // 绝对路径
        strncpy(full_path, dirname, MAX_PATH_LENGTH - 1);
    } else {  // 相对路径
        if (strcmp(current_path, "/") == 0) {
            snprintf(full_path, MAX_PATH_LENGTH, "/%s", dirname);
        } else {
            snprintf(full_path, MAX_PATH_LENGTH, "%s/%s", current_path, dirname);
        }
    }

    // 检查目录是否已存在
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, full_path) == 0) {
            printf("Error: Directory already exists.\n");
            fclose(vfs);
            return;
        }
    }

    // 创建新目录
    for (int i = 0; i < MAX_FILES; i++) {
        if (superblock.files[i].name[0] == '\0') {
            strncpy(superblock.files[i].name, full_path, MAX_FILENAME_LENGTH);
            superblock.files[i].is_directory = 1;
            superblock.files[i].permissions = PERM_READ | PERM_WRITE | PERM_EXECUTE;  // 默认所有权限
            fseek(vfs, 0, SEEK_SET);
            fwrite(&superblock, sizeof(SuperBlock), 1, vfs);
            printf("Directory created: %s\n", full_path);
            fclose(vfs);
            return;
        }
    }

    printf("Error: Maximum number of files reached.\n");
    fclose(vfs);
}



// 在文件开头添加
char current_path[MAX_PATH_LENGTH] = "/";

// 修改 format_partition 函数
void format_partition() {
    const char *vfs_filename = "virtual_disk.dat";
    FILE *vfs = fopen(vfs_filename, "wb");
    if (!vfs) {
        perror("Error creating virtual disk");
        return;
    }

    SuperBlock superblock;
    memset(&superblock, 0, sizeof(SuperBlock));

    // 创建根目录
    strncpy(superblock.files[0].name, "/", MAX_FILENAME_LENGTH);
    superblock.files[0].is_directory = 1;

    fwrite(&superblock, sizeof(SuperBlock), 1, vfs);

    // Allocate space for the virtual disk (e.g., 100MB)
    fseek(vfs, 100 * 1024 * 1024 - 1, SEEK_SET);
    fputc('\0', vfs);
    fclose(vfs);

    printf("Partition formatted and root directory created in %s.\n", vfs_filename);
    printf("Current path: %s\n", current_path);
}

void list_directory() {
    if (access("virtual_disk.dat", F_OK) == -1) {
        printf("Error: Disk partition not created.\n");
        return;
    }

    FILE *vfs = fopen("virtual_disk.dat", "rb");
    if (!vfs) {
        perror("Error opening virtual disk");
        return;
    }

    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    int found = 0;

    for (int i = 0; i < MAX_FILES; i++) {
        if (superblock.files[i].name[0] != '\0') {
            // 获取当前目录的路径长度
            size_t current_path_len = strlen(current_path);
            
            // 检查文件是否在当前目录下
            if (strncmp(superblock.files[i].name, current_path, current_path_len) == 0) {
                // 获取文件名部分
                const char *file_part = superblock.files[i].name + current_path_len;
                // 跳过开头的斜杠
                if (*file_part == '/') file_part++;
                
                // 检查是否是当前目录的直接子文件/目录
                if (*file_part != '\0' && !strchr(file_part, '/')) {
                    printf("%s%s  ", 
                        file_part,
                        superblock.files[i].is_directory ? "/" : "");
                    found++;
                }
            }
        }
    }

    if (found == 0) {
        printf("(empty directory)");
    }
    printf("\n");

    fclose(vfs);
}

// 修改 change_directory 函数
void change_directory(const char *dirname) {
    if (access("virtual_disk.dat", F_OK) == -1) {
        printf("Error: Disk partition not created.\n");
        return;
    }

    FILE *vfs = fopen("virtual_disk.dat", "rb");
    if (!vfs) {
        perror("Error opening virtual disk");
        return;
    }

    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    // 处理 "." 当前目录
    if (strcmp(dirname, ".") == 0) {
        fclose(vfs);
        return;
    }

    // 处理 ".." 父目录
    if (strcmp(dirname, "..") == 0) {
        if (strcmp(current_path, "/") != 0) {
            char *last_slash = strrchr(current_path, '/');
            if (last_slash == current_path) {
                strcpy(current_path, "/");
            } else {
                *last_slash = '\0';
            }
        }
        fclose(vfs);
        return;
    }

    // 构建目标路径
    char target_path[MAX_PATH_LENGTH];
    if (dirname[0] == '/') {  // 绝对路径
        strncpy(target_path, dirname, MAX_PATH_LENGTH - 1);
    } else {  // 相对路径
        if (strcmp(current_path, "/") == 0) {
            snprintf(target_path, MAX_PATH_LENGTH, "/%s", dirname);
        } else {
            snprintf(target_path, MAX_PATH_LENGTH, "%s/%s", current_path, dirname);
        }
    }

    // 检查目标目录是否存在
    int found = 0;
    for (int i = 0; i < MAX_FILES; i++) {
        // 精确匹配目录名
        if (strcmp(superblock.files[i].name, target_path) == 0 && 
            superblock.files[i].is_directory) {
            found = 1;
            strncpy(current_path, target_path, MAX_PATH_LENGTH - 1);
            printf("Changed to directory: %s\n", current_path);
            break;
        }
    }

    if (!found) {
        printf("Error: Directory '%s' not found.\n", target_path);
    }

    fclose(vfs);
}



void open_file(const char *filename) {
    if (access("virtual_disk.dat", F_OK) == -1) {
        printf("Error: Disk partition not created.\n");
        return;
    }

    FILE *vfs = fopen("virtual_disk.dat", "rb");
    if (!vfs) {
        perror("Error opening virtual disk");
        return;
    }

    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    // 构建完整路径
    char full_path[MAX_PATH_LENGTH];
    if (filename[0] == '/') {  // 绝对路径
        strncpy(full_path, filename, MAX_PATH_LENGTH - 1);
    } else {  // 相对路径
        if (strcmp(current_path, "/") == 0) {
            snprintf(full_path, MAX_PATH_LENGTH, "/%s", filename);
        } else {
            snprintf(full_path, MAX_PATH_LENGTH, "%s/%s", current_path, filename);
        }
    }

    // 查找文件
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, full_path) == 0 && !superblock.files[i].is_directory) {
            // 检查文件大小
            if (superblock.files[i].size == 0) {
                printf("(empty file)\n");
                fclose(vfs);
                return;
            }

            // 读取文件内容
            char *buffer = malloc(superblock.files[i].size + 1);
            if (!buffer) {
                printf("Error: Memory allocation failed.\n");
                fclose(vfs);
                return;
            }

            size_t total_read = 0;
            int current_page = superblock.files[i].first_page;
            size_t file_size = (size_t)superblock.files[i].size;  // 显式转换为size_t
            
            // 读取所有页面的内容
            while (current_page != -1 && total_read < file_size) {
                fseek(vfs, sizeof(SuperBlock) + current_page * PAGE_SIZE, SEEK_SET);
                size_t to_read = file_size - total_read;
                if (to_read > PAGE_SIZE) to_read = PAGE_SIZE;
                
                size_t bytes_read = fread(buffer + total_read, 1, to_read, vfs);
                total_read += bytes_read;
                
                current_page = superblock.page_table[current_page].next_page;
            }
            
            buffer[total_read] = '\0';
            printf("%s", buffer);
            if (buffer[total_read-1] != '\n') {
                printf("\n");
            }
            
            free(buffer);
            fclose(vfs);
            return;
        }
    }

    printf("Error: File not found.\n");
    fclose(vfs);
}

// 在write_file函数中添加分页支持
int allocate_pages(SuperBlock *sb, size_t size_needed) {
    int pages_needed = (size_needed + PAGE_SIZE - 1) / PAGE_SIZE;
    int first_page = -1;
    int prev_page = -1;
    
    for (int i = 0; i < pages_needed; i++) {
        if (sb->free_page_head == -1) {
            return -1;  // 没有足够的页面
        }
        
        int current_page = sb->free_page_head;
        sb->free_page_head = sb->page_table[current_page].next_page;
        
        sb->page_table[current_page].is_used = 1;
        sb->page_table[current_page].next_page = -1;
        
        if (first_page == -1) {
            first_page = current_page;
        }
        
        if (prev_page != -1) {
            sb->page_table[prev_page].next_page = current_page;
        }
        
        prev_page = current_page;
    }
    
    return first_page;
}

void write_file(const char *filename, const char *content) {
    if (access("virtual_disk.dat", F_OK) == -1) {
        printf("Error: Disk partition not created.\n");
        return;
    }

    FILE *vfs = fopen("virtual_disk.dat", "rb+");
    if (!vfs) {
        perror("Error opening virtual disk");
        return;
    }

    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    // 构建完整路径
    char full_path[MAX_PATH_LENGTH];
    if (filename[0] == '/') {  // 绝对路径
        strncpy(full_path, filename, MAX_PATH_LENGTH - 1);
    } else {  // 相对路径
        if (strcmp(current_path, "/") == 0) {
            snprintf(full_path, MAX_PATH_LENGTH, "/%s", filename);
        } else {
            snprintf(full_path, MAX_PATH_LENGTH, "%s/%s", current_path, filename);
        }
    }

    // 查找文件
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, full_path) == 0 && !superblock.files[i].is_directory) {
            size_t content_size = strlen(content);
            
            // 释放原有页面
            int current_page = superblock.files[i].first_page;
            while (current_page != -1) {
                int next_page = superblock.page_table[current_page].next_page;
                superblock.page_table[current_page].is_used = 0;
                current_page = next_page;
            }

            // 分配新页面
            int first_page = -1;
            int prev_page = -1;
            size_t remaining = content_size;
            size_t offset = 0;

            while (remaining > 0) {
                // 查找空闲页面
                int new_page = -1;
                for (int j = 0; j < MAX_FILES * MAX_FILE_PAGES; j++) {
                    if (!superblock.page_table[j].is_used) {
                        new_page = j;
                        superblock.page_table[j].is_used = 1;
                        superblock.page_table[j].next_page = -1;
                        break;
                    }
                }

                if (new_page == -1) {
                    printf("Error: No free pages available.\n");
                    fclose(vfs);
                    return;
                }

                // 链接页面
                if (first_page == -1) {
                    first_page = new_page;
                } else {
                    superblock.page_table[prev_page].next_page = new_page;
                }
                prev_page = new_page;

                // 写入内容
                size_t write_size = (remaining > PAGE_SIZE) ? PAGE_SIZE : remaining;
                fseek(vfs, sizeof(SuperBlock) + new_page * PAGE_SIZE, SEEK_SET);
                fwrite(content + offset, 1, write_size, vfs);

                offset += write_size;
                remaining -= write_size;
            }

            // 更新文件信息
            superblock.files[i].first_page = first_page;
            superblock.files[i].size = content_size;
            superblock.files[i].page_count = (content_size + PAGE_SIZE - 1) / PAGE_SIZE;

            // 更新超级块
            fseek(vfs, 0, SEEK_SET);
            fwrite(&superblock, sizeof(SuperBlock), 1, vfs);
            printf("Content written to file: %s\n", full_path);
            fclose(vfs);
            return;
        }
    }

    printf("Error: File not found.\n");
    fclose(vfs);
}


void delete_directory(const char *dirname) {
    if (access("virtual_disk.dat", F_OK) == -1) {
        printf("Error: Disk partition not created.\n");
        return;
    }

    FILE *vfs = fopen("virtual_disk.dat", "rb+");
    if (!vfs) {
        perror("Error opening virtual disk");
        return;
    }

    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    // 构建完整路径
    char full_path[MAX_PATH_LENGTH];
    if (dirname[0] == '/') {  // 绝对路径
        strncpy(full_path, dirname, MAX_PATH_LENGTH - 1);
    } else {  // 相对路径
        if (strcmp(current_path, "/") == 0) {
            snprintf(full_path, MAX_PATH_LENGTH, "/%s", dirname);
        } else {
            snprintf(full_path, MAX_PATH_LENGTH, "%s/%s", current_path, dirname);
        }
    }

    // 不允许删除根目录
    if (strcmp(full_path, "/") == 0) {
        printf("Error: Cannot delete root directory.\n");
        fclose(vfs);
        return;
    }

    // 检查目录是否存在
    int dir_index = -1;
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, full_path) == 0 && 
            superblock.files[i].is_directory) {
            dir_index = i;
            break;
        }
    }

    if (dir_index == -1) {
        printf("Error: Directory not found.\n");
        fclose(vfs);
        return;
    }

    // 检查目录是否为空
    size_t path_len = strlen(full_path);
    int has_contents = 0;
    for (int i = 0; i < MAX_FILES; i++) {
        if (superblock.files[i].name[0] != '\0' && 
            strncmp(superblock.files[i].name, full_path, path_len) == 0 &&
            i != dir_index) {
            const char *remaining = superblock.files[i].name + path_len;
            if (*remaining == '/') {
                has_contents = 1;
                break;
            }
        }
    }

    if (has_contents) {
        printf("Directory not empty. Do you want to delete all contents? (y/n): ");
        char response;
        scanf(" %c", &response);
        getchar(); // 消耗换行符

        if (response != 'y' && response != 'Y') {
            printf("Operation cancelled.\n");
            fclose(vfs);
            return;
        }

        // 递归删除所有内容
        for (int i = 0; i < MAX_FILES; i++) {
            if (superblock.files[i].name[0] != '\0' && 
                strncmp(superblock.files[i].name, full_path, path_len) == 0) {
                memset(&superblock.files[i], 0, sizeof(FileEntry));
            }
        }
    }

    // 删除目录本身
    memset(&superblock.files[dir_index], 0, sizeof(FileEntry));
    fseek(vfs, 0, SEEK_SET);
    fwrite(&superblock, sizeof(SuperBlock), 1, vfs);
    printf("Directory deleted: %s\n", full_path);

    fclose(vfs);
}

void print_working_directory() {
    printf("%s\n", current_path);
}


void move_directory(const char *source, const char *destination) {
    if (access("virtual_disk.dat", F_OK) == -1) {
        printf("Error: Disk partition not created.\n");
        return;
    }

    FILE *vfs = fopen("virtual_disk.dat", "rb+");
    if (!vfs) {
        perror("Error opening virtual disk");
        return;
    }

    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    // 构建源路径
    char src_path[MAX_PATH_LENGTH];
    if (source[0] == '/') {  // 绝对路径
        strncpy(src_path, source, MAX_PATH_LENGTH - 1);
    } else {  // 相对路径
        if (strcmp(current_path, "/") == 0) {
            snprintf(src_path, MAX_PATH_LENGTH, "/%s", source);
        } else {
            snprintf(src_path, MAX_PATH_LENGTH, "%s/%s", current_path, source);
        }
    }

    // 构建目标路径
    char dest_path[MAX_PATH_LENGTH];
    if (destination[0] == '/') {  // 绝对路径
        strncpy(dest_path, destination, MAX_PATH_LENGTH - 1);
    } else {  // 相对路径
        if (strcmp(current_path, "/") == 0) {
            snprintf(dest_path, MAX_PATH_LENGTH, "/%s", destination);
        } else {
            snprintf(dest_path, MAX_PATH_LENGTH, "%s/%s", current_path, destination);
        }
    }

    // 不允许移动根目录
    if (strcmp(src_path, "/") == 0) {
        printf("Error: Cannot move root directory.\n");
        fclose(vfs);
        return;
    }

    // 查找源目录
    int src_index = -1;
    size_t src_path_len = strlen(src_path);
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, src_path) == 0 && 
            superblock.files[i].is_directory) {
            src_index = i;
            break;
        }
    }

    if (src_index == -1) {
        printf("Error: Source directory not found.\n");
        fclose(vfs);
        return;
    }

    // 检查目标路径是否已存在
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, dest_path) == 0) {
            printf("Error: Destination already exists.\n");
            fclose(vfs);
            return;
        }
    }

    // 移动目录及其内容
    for (int i = 0; i < MAX_FILES; i++) {
        if (superblock.files[i].name[0] != '\0' && 
            strncmp(superblock.files[i].name, src_path, src_path_len) == 0) {
            char new_path[MAX_PATH_LENGTH];
            const char *remaining = superblock.files[i].name + src_path_len;
            if (i == src_index) {
                strcpy(new_path, dest_path);
            } else {
                snprintf(new_path, MAX_PATH_LENGTH, "%s%s", dest_path, remaining);
            }
            strncpy(superblock.files[i].name, new_path, MAX_FILENAME_LENGTH);
        }
    }

    // 保存更改
    fseek(vfs, 0, SEEK_SET);
    fwrite(&superblock, sizeof(SuperBlock), 1, vfs);
    printf("Directory moved from %s to %s\n", src_path, dest_path);

    fclose(vfs);
}


void defragment() {
    FILE *vfs = fopen("virtual_disk.dat", "rb+");
    if (!vfs) return;

    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    // 整理空闲页面链表
    int free_pages[MAX_FILES * MAX_FILE_PAGES];
    int free_count = 0;
    
    for (int i = 0; i < MAX_FILES * MAX_FILE_PAGES; i++) {
        if (!superblock.page_table[i].is_used) {
            free_pages[free_count++] = i;
        }
    }
    
    // 重建空闲页面链表
    superblock.free_page_head = free_pages[0];
    for (int i = 0; i < free_count - 1; i++) {
        superblock.page_table[free_pages[i]].next_page = free_pages[i + 1];
    }
    superblock.page_table[free_pages[free_count - 1]].next_page = -1;

    fseek(vfs, 0, SEEK_SET);
    fwrite(&superblock, sizeof(SuperBlock), 1, vfs);
    fclose(vfs);
}


void show_permissions(const char *path) {
    if (access("virtual_disk.dat", F_OK) == -1) {
        printf("Error: Disk partition not created.\n");
        return;
    }

    FILE *vfs = fopen("virtual_disk.dat", "rb");
    if (!vfs) {
        perror("Error opening virtual disk");
        return;
    }

    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    // 构建完整路径
    char full_path[MAX_PATH_LENGTH];
    if (path[0] == '/') {  // 绝对路径
        strncpy(full_path, path, MAX_PATH_LENGTH - 1);
    } else {  // 相对路径
        if (strcmp(current_path, "/") == 0) {
            snprintf(full_path, MAX_PATH_LENGTH, "/%s", path);
        } else {
            snprintf(full_path, MAX_PATH_LENGTH, "%s/%s", current_path, path);
        }
    }

    // 查找文件或目录
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, full_path) == 0) {
            // 显示类型和权限
            printf("%c", superblock.files[i].is_directory ? 'd' : '-');
            
            // 显示读权限
            printf("%c", (superblock.files[i].permissions & PERM_READ) ? 'r' : '-');
            
            // 显示写权限
            printf("%c", (superblock.files[i].permissions & PERM_WRITE) ? 'w' : '-');
            
            // 显示执行权限
            printf("%c", (superblock.files[i].permissions & PERM_EXECUTE) ? 'x' : '-');
            
            printf(" %s\n", full_path);
            fclose(vfs);
            return;
        }
    }

    printf("Error: File or directory not found.\n");
    fclose(vfs);
}

void change_permissions(const char *path, const char *perm_str) {
    if (access("virtual_disk.dat", F_OK) == -1) {
        printf("Error: Disk partition not created.\n");
        return;
    }

    FILE *vfs = fopen("virtual_disk.dat", "rb+");
    if (!vfs) {
        perror("Error opening virtual disk");
        return;
    }

    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    // 构建完整路径
    char full_path[MAX_PATH_LENGTH];
    if (path[0] == '/') {
        strncpy(full_path, path, MAX_PATH_LENGTH - 1);
    } else {
        if (strcmp(current_path, "/") == 0) {
            snprintf(full_path, MAX_PATH_LENGTH, "/%s", path);
        } else {
            snprintf(full_path, MAX_PATH_LENGTH, "%s/%s", current_path, path);
        }
    }

    // 解析权限字符串
    unsigned char new_perm = 0;
    if (strlen(perm_str) != 3) {
        printf("Error: Invalid permission format. Use format: rwx (e.g., rw-, r-x)\n");
        fclose(vfs);
        return;
    }

    if (perm_str[0] == 'r') new_perm |= PERM_READ;
    if (perm_str[1] == 'w') new_perm |= PERM_WRITE;
    if (perm_str[2] == 'x') new_perm |= PERM_EXECUTE;

    // 查找并修改文件/目录权限
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, full_path) == 0) {
            superblock.files[i].permissions = new_perm;
            
            // 更新超级块
            fseek(vfs, 0, SEEK_SET);
            fwrite(&superblock, sizeof(SuperBlock), 1, vfs);
            printf("Changed permissions of '%s' to %s\n", full_path, perm_str);
            fclose(vfs);
            return;
        }
    }

    printf("Error: File or directory not found.\n");
    fclose(vfs);
}


void link_file(const char *source, const char *link_name) {
    if (access("virtual_disk.dat", F_OK) == -1) {
        printf("Error: Disk partition not created.\n");
        return;
    }

    FILE *vfs = fopen("virtual_disk.dat", "rb+");
    if (!vfs) {
        perror("Error opening virtual disk");
        return;
    }

    SuperBlock superblock;
    fread(&superblock, sizeof(SuperBlock), 1, vfs);

    // 构建源文件完整路径
    char src_path[MAX_PATH_LENGTH];
    if (source[0] == '/') {
        strncpy(src_path, source, MAX_PATH_LENGTH - 1);
    } else {
        if (strcmp(current_path, "/") == 0) {
            snprintf(src_path, MAX_PATH_LENGTH, "/%s", source);
        } else {
            snprintf(src_path, MAX_PATH_LENGTH, "%s/%s", current_path, source);
        }
    }

    // 构建链接文件完整路径
    char link_path[MAX_PATH_LENGTH];
    if (link_name[0] == '/') {
        strncpy(link_path, link_name, MAX_PATH_LENGTH - 1);
    } else {
        if (strcmp(current_path, "/") == 0) {
            snprintf(link_path, MAX_PATH_LENGTH, "/%s", link_name);
        } else {
            snprintf(link_path, MAX_PATH_LENGTH, "%s/%s", current_path, link_name);
        }
    }

    // 查找源文件
    int src_index = -1;
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, src_path) == 0 && !superblock.files[i].is_directory) {
            src_index = i;
            break;
        }
    }

    if (src_index == -1) {
        printf("Error: Source file not found.\n");
        fclose(vfs);
        return;
    }

    // 检查目标路径是否已存在
    for (int i = 0; i < MAX_FILES; i++) {
        if (strcmp(superblock.files[i].name, link_path) == 0) {
            printf("Error: Link name already exists.\n");
            fclose(vfs);
            return;
        }
    }

    // 查找空闲文件条目
    int link_index = -1;
    for (int i = 0; i < MAX_FILES; i++) {
        if (superblock.files[i].name[0] == '\0') {
            link_index = i;
            break;
        }
    }

    if (link_index == -1) {
        printf("Error: No free file entries available.\n");
        fclose(vfs);
        return;
    }

    // 创建硬链接
    strncpy(superblock.files[link_index].name, link_path, MAX_FILENAME_LENGTH);
    superblock.files[link_index].size = superblock.files[src_index].size;
    superblock.files[link_index].first_page = superblock.files[src_index].first_page;
    superblock.files[link_index].page_count = superblock.files[src_index].page_count;
    superblock.files[link_index].is_directory = 0;
    superblock.files[link_index].permissions = superblock.files[src_index].permissions;
    
    // 增加链接计数
    superblock.files[src_index].link_count++;
    superblock.files[link_index].link_count = superblock.files[src_index].link_count;

    // 更新所有指向相同内容的文件的链接计数
    int first_page = superblock.files[src_index].first_page;
    for (int i = 0; i < MAX_FILES; i++) {
        if (superblock.files[i].name[0] != '\0' && 
            !superblock.files[i].is_directory &&
            superblock.files[i].first_page == first_page) {
            superblock.files[i].link_count = superblock.files[src_index].link_count;
        }
    }
    
    // 更新超级块
    fseek(vfs, 0, SEEK_SET);
    fwrite(&superblock, sizeof(SuperBlock), 1, vfs);
    printf("Hard link created: %s -> %s\n", link_path, src_path);

    fclose(vfs);
}